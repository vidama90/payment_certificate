sap.ui.define(
    ["sap/suite/ui/generic/template/lib/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.atg.ppm.paymentcert.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);